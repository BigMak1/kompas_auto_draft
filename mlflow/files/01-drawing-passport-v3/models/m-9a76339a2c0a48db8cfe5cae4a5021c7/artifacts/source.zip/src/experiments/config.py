"""Конфигурация исследования и проверка манифеста датасета dev/val."""

from pathlib import Path
from typing import Annotated, Literal, Self

import numpy as np
import yaml
from pydantic import Field, model_validator

from src.config import ROOT, AgentSettings, CadSettings, EvaluationSettings, Settings
from src.utils import read_json, require_orientation, require_single_sheet, sha256

DEFAULT_CONFIG = ROOT / "configs/experiments/passport.yaml"

Variant = Literal["direct", "passport_only", "passport_png", "notes_png"]
VARIANTS = ("direct", "passport_only", "passport_png", "notes_png")
LABELS = {
    "direct": "Прямой baseline",
    "passport_only": "Только паспорт",
    "passport_png": "Паспорт + PNG",
    "notes_png": "Заметки + PNG",
}
SafeName = Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_-]*$")]


class ReadingSettings(Settings):
    max_output_tokens: int = Field(gt=0)
    prompt_version: str = Field(min_length=1)
    prompt: str = Field(min_length=1)
    passport_format: str = Field(min_length=1)
    notes_format: str = Field(min_length=1)


class ExperimentConfig(Settings):
    name: SafeName
    manifest: str
    variants: list[Variant]
    repeats: int = Field(default=3, ge=1, le=100)
    validation_size: int = Field(default=5, ge=1)
    order_seed: int = Field(default=20261115, ge=0)
    agent: AgentSettings
    reading: ReadingSettings
    cad: CadSettings
    evaluation: EvaluationSettings

    @model_validator(mode="after")
    def budget(self) -> Self:
        if not self.variants or len(set(self.variants)) != len(self.variants):
            raise ValueError("Маршруты должны быть непустыми и не повторяться")
        if self.reading.max_output_tokens >= self.agent.max_output_tokens:
            raise ValueError("Чтение должно оставлять выходной бюджет для рецепта")
        if Path(self.manifest).is_absolute() or ".." in Path(self.manifest).parts:
            raise ValueError("Путь манифеста датасета должен быть относительным внутри репозитория")
        return self


def load_experiment(path: Path = DEFAULT_CONFIG) -> ExperimentConfig:
    return ExperimentConfig.model_validate(yaml.safe_load(path.read_text(encoding="utf-8")))


def check_manifest(root: Path, config: ExperimentConfig, *, require_val: bool = True) -> dict:
    """Ни исходный корпус, ни КОМПАС для проверки не требуются."""
    from src.evaluate import load_mesh

    path = root / config.manifest
    manifest = read_json(path)
    items = manifest["items"]
    names = [item["pair_id"] for item in items]
    if not names or len(names) != len(set(names)):
        raise ValueError("Манифест датасета должен содержать уникальные детали")
    if manifest["coordinates"]["units"] != "mm":
        raise ValueError("Ожидаются миллиметры")
    families: dict[str, set[str]] = {"dev": set(), "val": set()}
    hashes: dict[str, set[str]] = {"dev": set(), "val": set()}
    for item in items:
        require_single_sheet(item)
        require_orientation(item)
        split = item["split"]
        if split not in families or not item.get("family"):
            raise ValueError("Для каждой детали нужны dev/val и группа родства")
        families[split].add(item["family"])
        for field, folder, extension in (("input_png", "input", "png"), ("target_mesh", "target", "stl")):
            entry = item[field]
            if entry["path"] != f"{folder}/{item['pair_id']}.{extension}":
                raise ValueError(f"Некорректный путь {field}")
            source = path.parent / entry["path"]
            if source.is_symlink() or not source.is_file() or sha256(source) != entry["sha256"]:
                raise ValueError(f"Файл отсутствует, подменён или изменён: {entry['path']}")
            hashes[split].add(entry["sha256"])
        mesh = load_mesh(path.parent / item["target_mesh"]["path"])
        if not mesh.is_volume or not np.isfinite(mesh.vertices).all() or abs(mesh.bounds[0, 2]) > 1e-5:
            raise ValueError(f"{item['pair_id']}: некорректное тело или Zmin != 0")
        if split == "val" and item.get("review", {}).get("status") != "accepted":
            raise ValueError(f"{item['pair_id']}: проверочная пара не принята")
        if item.get("preparation"):
            matrix = np.array(item["preparation"]["transform_to_target"], dtype=float)
            if (
                matrix.shape != (4, 4)
                or not np.isfinite(matrix).all()
                or not np.allclose(matrix[3], (0, 0, 0, 1))
                or not np.allclose(matrix[:3, :3] @ matrix[:3, :3].T, np.eye(3))
                or not np.isclose(np.linalg.det(matrix[:3, :3]), 1)
            ):
                raise ValueError("Подготовка эталона допускает только поворот и перенос")
    if families["dev"] & families["val"] or hashes["dev"] & hashes["val"]:
        raise ValueError("Родственные детали или одинаковые файлы попали в dev и val")
    if require_val and (
        manifest.get("status") != "ready"
        or sum(item["split"] == "val" for item in items) != config.validation_size
    ):
        raise ValueError("Проверочная выборка ещё не подготовлена полностью")
    return manifest
