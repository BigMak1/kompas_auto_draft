"""Команды экспериментов; выполнение серий находится в runner.py."""

import argparse
import asyncio
from pathlib import Path

from src.config import ROOT
from src.experiments.config import DEFAULT_CONFIG, check_manifest, load_experiment
from src.experiments.store import study_path
from src.utils import error_details, log, log_error


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Эксперименты: запуск серий, оценка и отчёт")
    commands = parser.add_subparsers(dest="command")
    config_help = "YAML исследования (по умолчанию configs/experiments/passport.yaml)"
    run = commands.add_parser("run", help="Выполнить или продолжить серию")
    run.add_argument("--config", type=Path, default=DEFAULT_CONFIG, help=config_help)
    run.add_argument("--split", choices=("dev", "val"), required=True)
    run.add_argument("--pair", action="append")
    run.add_argument("--repeats", type=int)
    run.add_argument("--study")
    run.add_argument(
        "--retry-infrastructure", action="store_true", help="Отдельные попытки для технических ошибок"
    )
    for command in ("evaluate", "report", "track"):
        sub = commands.add_parser(command)
        sub.add_argument("--study", required=True)
    check = commands.add_parser("check", help="Проверить конфиг, схемы и данные без API")
    check.add_argument("--config", type=Path, default=DEFAULT_CONFIG, help=config_help)
    check.add_argument("--dev-only", action="store_true")
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 0
    try:
        if args.command == "check":
            config = load_experiment(args.config)
            check_manifest(ROOT, config, require_val=not args.dev_only)
            log("ГОТОВО", "Конфиг и манифест датасета проверены; запросов к API нет")
            return 0
        if args.command == "run":
            from filelock import FileLock

            from src.experiments.runner import run_matrix

            config = load_experiment(args.config)
            name = args.study or (config.name if args.split == "val" else config.name + "-dev")
            lock = ROOT / "artifacts" / (study_path(ROOT, name).name + ".lock")
            lock.parent.mkdir(parents=True, exist_ok=True)
            with FileLock(lock, timeout=0):
                asyncio.run(
                    run_matrix(
                        ROOT,
                        config,
                        name,
                        args.split,
                        args.pair,
                        args.repeats if args.repeats is not None else config.repeats,
                        retry=args.retry_infrastructure,
                    )
                )
            return 0
        if args.command == "track":
            from src.experiments.tracking import sync_study

            sync_study(study_path(ROOT, args.study), ROOT)
            return 0
        from src.experiments.report import evaluate_study, report_study

        if args.command == "evaluate":
            evaluate_study(ROOT, args.study)
        summary = report_study(ROOT, args.study)
        return 0 if summary["complete"] else 1
    except Exception as error:  # noqa: BLE001 — краткая причина в терминале, подробности отдельно.
        log_error(error_details(error, "эксперимент"), ROOT / "artifacts/experiment-error.log")
        return 1
