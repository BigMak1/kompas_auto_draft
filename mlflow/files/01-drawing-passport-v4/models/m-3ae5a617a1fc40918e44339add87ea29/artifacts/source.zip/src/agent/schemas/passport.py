"""Структурированный паспорт: наблюдения чертежа, а не инструкции построения CAD."""

from typing import Annotated, Literal, Self

from pydantic import Field, model_validator

from src.agent.schemas.base import StrictModel

Identifier = Annotated[str, Field(min_length=1, max_length=64)]
Text = Annotated[str, Field(min_length=1, max_length=2000)]
Status = Literal["observed", "hypothesis", "unresolved"]


class View(StrictModel):
    id: Identifier
    label: Text
    kind: Literal["view", "section", "detail", "table", "other"]
    description: Text


class Coordinates(StrictModel):
    origin: Text
    axis_z: Text
    front_view_id: Identifier | None
    status: Status


class Feature(StrictModel):
    id: Identifier
    kind: Text
    description: Text
    view_ids: Annotated[list[Identifier], Field(max_length=32)]
    status: Status


class Dimension(StrictModel):
    id: Identifier
    name: Text
    raw: Text | None
    value: Annotated[float, Field(allow_inf_nan=False)] | None
    unit: Literal["mm", "degree", "count"] | None
    view_id: Identifier | None
    feature_id: Identifier | None
    reading_status: Status
    binding_status: Status

    @model_validator(mode="after")
    def evidence(self) -> Self:
        if self.reading_status == "unresolved" and self.value is not None:
            raise ValueError("Непрочитанный размер: value должен быть null")
        if self.reading_status == "observed" and (not self.raw or not self.view_id):
            raise ValueError("Наблюдаемый размер требует исходной надписи и вида")
        if self.value is not None and self.unit is None:
            raise ValueError("Число требует единицы измерения")
        if self.binding_status == "unresolved" and self.feature_id is not None:
            raise ValueError("Неизвестный владелец размера: feature_id должен быть null")
        if self.binding_status == "observed" and self.feature_id is None:
            raise ValueError("Наблюдаемая привязка требует feature_id")
        return self


class Relation(StrictModel):
    feature_ids: Annotated[list[Identifier], Field(min_length=2, max_length=16)]
    description: Text
    status: Status


class Passport(StrictModel):
    schema_version: Literal["drawing-passport-1"]
    views: Annotated[list[View], Field(min_length=1, max_length=32)]
    coordinates: Coordinates
    features: Annotated[list[Feature], Field(max_length=80)]
    dimensions: Annotated[list[Dimension], Field(max_length=160)]
    relations: Annotated[list[Relation], Field(max_length=80)]
    unresolved: Annotated[list[Text], Field(max_length=80)]

    @model_validator(mode="after")
    def references(self) -> Self:
        groups = (self.views, self.features, self.dimensions)
        ids = [item.id for group in groups for item in group]
        if len(ids) != len(set(ids)):
            raise ValueError("ID записей паспорта должны быть уникальны")
        views = {item.id for item in self.views}
        features = {item.id for item in self.features}
        view_refs = [ref for feature in self.features for ref in feature.view_ids]
        view_refs += [d.view_id for d in self.dimensions if d.view_id is not None]
        if self.coordinates.front_view_id is not None:
            view_refs.append(self.coordinates.front_view_id)
        feature_refs = [d.feature_id for d in self.dimensions if d.feature_id is not None]
        feature_refs += [ref for relation in self.relations for ref in relation.feature_ids]
        if set(view_refs) - views or set(feature_refs) - features:
            raise ValueError("Паспорт ссылается на отсутствующий вид или элемент")
        return self
