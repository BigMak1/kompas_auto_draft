"""Локальная история MLflow: прогоны, версии агента, данные и переносимые артефакты."""

import json
import logging
import os
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from filelock import FileLock

from src.config import ROOT
from src.experiments.logging import log, log_error
from src.experiments.store import digest, read_record, verify_study
from src.utils import error_details, read_json, sha256

SYNC_VERSION = 2


def uri(root: Path) -> str:
    directory = (root / "artifacts/mlflow").resolve()
    directory.mkdir(parents=True, exist_ok=True)
    return "sqlite:///" + (directory / "tracking.db").as_posix()


@contextmanager
def local_tracking(root: Path) -> Iterator[Any]:
    """Даже при внешнем MLFLOW_TRACKING_URI проект использует свою локальную базу."""
    os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")
    os.environ.setdefault("MLFLOW_DISABLE_TELEMETRY", "true")
    import mlflow

    previous = mlflow.get_tracking_uri()
    attachments = os.environ.get("MLFLOW_TRACE_EXTRACT_ATTACHMENTS")
    # Иначе MLflow выносит base64 в отдельный файл раньше фильтра span_processors.
    os.environ["MLFLOW_TRACE_EXTRACT_ATTACHMENTS"] = "false"
    mlflow.set_tracking_uri(uri(root))
    try:
        yield mlflow
    finally:
        mlflow.set_tracking_uri(previous)
        if attachments is None:
            os.environ.pop("MLFLOW_TRACE_EXTRACT_ATTACHMENTS", None)
        else:
            os.environ["MLFLOW_TRACE_EXTRACT_ATTACHMENTS"] = attachments


def parameters(study: dict) -> dict:
    config = study["config"]
    result = {}
    for section in ("agent", "reading", "cad", "evaluation"):
        for key, value in config.get(section, {}).items():
            if key not in {"prompt", "passport_format", "notes_format"}:
                result[f"{section}.{key}"] = str(value)
    result["order_seed"] = str(config["order_seed"])
    return result


def ensure_experiment(client: Any, root: Path, study: dict) -> str:
    name = study["config"]["name"] + " · " + study["config"].get("title", "Сравнение маршрутов")
    legacy = (
        client.get_experiment_by_name("hw2-" + study["name"]) if "number" not in study["config"] else None
    )
    experiment = legacy or client.get_experiment_by_name(name)
    return (
        experiment.experiment_id
        if experiment
        else client.create_experiment(
            name, artifact_location=(root / "artifacts/mlflow/files").resolve().as_uri()
        )
    )


def ensure_datasets(mlflow: Any, experiment_id: str, study: dict) -> dict[str, Any]:
    """GenAI Datasets показывает карточки; DatasetInput фиксирует использованную выборку."""
    from mlflow.entities import Dataset
    from mlflow.genai.datasets import create_dataset, search_datasets

    manifest = study["manifest"]
    existing = search_datasets(experiment_ids=[experiment_id], max_results=1000)
    for split in sorted({item["split"] for item in manifest["items"]}):
        items = [item for item in manifest["items"] if item["split"] == split]
        checksum = digest(items)
        name = f"drawing-cad-{split}-{checksum[:12]}"
        dataset = next((d for d in existing if d.name == name), None)
        if dataset is None:
            dataset = create_dataset(
                name=name,
                experiment_id=[experiment_id],
                tags={
                    "split": split,
                    "sha256": checksum,
                    "source": manifest.get("dataset_id", "drawing-cad"),
                    "manifest": study["config"]["manifest"],
                },
            )
            dataset.merge_records(
                [
                    {
                        "inputs": {
                            "pair_id": item["pair_id"],
                            "png": item["input_png"]["path"],
                            "png_sha256": item["input_png"]["sha256"],
                            "orientation": item["orientation"],
                        },
                        "expectations": {
                            "stl": item["target_mesh"]["path"],
                            "stl_sha256": item["target_mesh"]["sha256"],
                            "family": item.get("family"),
                            "limitations": item.get("limitations", []),
                        },
                    }
                    for item in items
                ]
            )
    selected = [i for i in manifest["items"] if i["pair_id"] in study["pairs"]]
    return {
        "input": Dataset(
            name=manifest.get("dataset_id", "drawing-cad") + "-" + study["split"],
            digest=digest(selected)[:32],
            source_type="code",
            source=json.dumps({"tags": {"manifest": study["config"]["manifest"], "study": study["name"]}}),
            profile=json.dumps({"num_rows": len(selected)}),
        )
    }


def ensure_model(mlflow: Any, client: Any, directory: Path, experiment_id: str, study: dict) -> str:
    config = study["config"]
    version = digest(
        {
            "agent": config["agent"],
            "reading": config["reading"],
            "cad": config["cad"],
            "source": study["source_sha256"],
            "dependencies": study["versions"],
        }
    )
    found = client.search_logged_models([experiment_id], filter_string=f"tags.agent_version = '{version}'")
    if found:
        return found[0].model_id
    model = mlflow.create_external_model(
        name=f"drawing-cad-{version[:12]}",
        model_type="agent",
        experiment_id=experiment_id,
        tags={
            "agent_version": version,
            "config_version": config["name"],
            "description": "Версия кода, промптов и настроек CAD-агента; без собственных весов",
        },
        params={k: v for k, v in parameters(study).items() if not k.startswith("evaluation.")},
    )
    client.log_model_artifact(model.model_id, str(directory / "study.json"))
    client.log_model_artifact(model.model_id, str(directory / "source.zip"))
    return model.model_id


def prepare_tracking(root: Path, directory: Path) -> dict:
    """Подготовка до генерации; код и эталоны не передаются в контекст LLM."""
    with local_tracking(root) as mlflow:
        from mlflow.tracking import MlflowClient

        study = verify_study(directory)
        client = MlflowClient(tracking_uri=uri(root))
        experiment_id = ensure_experiment(client, root, study)
        with FileLock(root / "artifacts/mlflow/catalog.lock"):
            datasets = ensure_datasets(mlflow, experiment_id, study)
            model_id = ensure_model(mlflow, client, directory, experiment_id, study)
        return {"study": study, "experiment_id": experiment_id, "model_id": model_id, **datasets}


def ensure_run(
    client: Any, root: Path, directory: Path, destination: Path, study: dict, experiment_id: str
) -> str:
    identity = destination.relative_to(directory).as_posix()
    found = client.search_runs(
        [experiment_id],
        filter_string=(f"tags.study = '{study['name']}' AND tags.attempt = '{identity}'"),
        max_results=2,
    )
    if found:
        return found[0].info.run_id
    # Совместимость с записями прежней реализации, до появления тега attempt.
    mapping_path = root / "artifacts/mlflow" / f"{study['name']}.json"
    mapping = read_json(mapping_path) if mapping_path.exists() else {}
    if identity in mapping:
        from mlflow.exceptions import MlflowException

        try:
            run = client.get_run(mapping[identity]["run_id"])
            if run.info.experiment_id == experiment_id:
                client.set_tag(run.info.run_id, "attempt", identity)
                return run.info.run_id
        except MlflowException as error:
            if error.error_code != "RESOURCE_DOES_NOT_EXIST":
                raise
    record = read_record(destination)
    tags = {
        "mlflow.runName": identity,
        "study": study["name"],
        "attempt": identity,
        "split": study["split"],
        "kind": record["kind"],
        "pair_id": record["pair_id"],
    }
    return client.create_run(experiment_id, tags=tags).info.run_id


def sync_study(directory: Path, root: Path) -> dict:
    """Повторная синхронизация не дублирует результаты, метрики и связи."""
    context = prepare_tracking(root, directory)
    study = context["study"]
    from mlflow.entities import DatasetInput, InputTag, LoggedModelInput
    from mlflow.tracking import MlflowClient

    client = MlflowClient(tracking_uri=uri(root))
    for name in ("mlflow", "alembic", "sqlalchemy"):
        logging.getLogger(name).setLevel(logging.WARNING)
    count = measured = 0
    with FileLock(root / "artifacts/mlflow/sync.lock"):
        for path in sorted(directory.glob("*/*/record.json")):
            record = read_record(path.parent)
            identity = path.parent.relative_to(directory).as_posix()
            run_id = ensure_run(client, root, directory, path.parent, study, context["experiment_id"])
            saved = client.get_run(run_id)
            params = {
                **parameters(study),
                "variant": record.get("variant", record.get("stage", "reading")),
                "repeat": str(record["repeat"]),
                "model": study["config"]["agent"]["model"],
                "reasoning_effort": study["config"]["agent"]["reasoning_effort"],
                "max_output_tokens": str(study["config"]["agent"]["max_output_tokens"]),
                "timeout_seconds": str(study["config"]["agent"]["timeout_seconds"]),
                "study_fingerprint": study["fingerprint"],
                "agent_version_id": context["model_id"],
                "dataset_digest": context["input"].digest,
            }
            for key, value in params.items():
                if key not in saved.data.params:
                    client.log_param(run_id, key, value)
            client.set_tag(run_id, "outcome", record["status"])
            client.set_tag(run_id, "shared_reading", record.get("reading_path", ""))
            if record.get("error"):
                error = record["error"]
                client.set_tag(run_id, "error.stage", error.get("stage", record.get("stage", "unknown")))
                client.set_tag(run_id, "error.reason", error.get("summary", error["message"])[:4000])
            checksum = sha256(path)
            if saved.data.tags.get("record_sha256") != checksum:
                for key, value in {"seconds": record.get("seconds"), **(record.get("usage") or {})}.items():
                    if key in {"seconds", "input_tokens", "output_tokens"} and value is not None:
                        # Старые записи уже содержат эти точки — миграция не создаёт вторую.
                        if saved.data.metrics.get(key) != value:
                            client.log_metric(run_id, key, value)
                client.log_artifacts(run_id, str(path.parent))
                client.log_artifact(run_id, str(directory / "study.json"))
                client.set_tag(run_id, "record_sha256", checksum)
            if saved.data.tags.get("tracking_schema") != str(SYNC_VERSION):
                client.log_inputs(
                    run_id,
                    datasets=[
                        DatasetInput(context["input"], [InputTag("mlflow.data.context", study["split"])])
                    ],
                    models=[LoggedModelInput(context["model_id"])],
                )
                # В MLflow можно скачать фактические вход и эталон данной попытки.
                item = next(i for i in study["manifest"]["items"] if i["pair_id"] == record["pair_id"])
                for field in ("input_png", "target_mesh"):
                    asset = (root / study["config"]["manifest"]).parent / item[field]["path"]
                    if not asset.is_file() or sha256(asset) != item[field]["sha256"]:
                        raise ValueError(f"Файл датасета изменён: {asset}")
                    client.log_artifact(run_id, str(asset), artifact_path="data/" + field)
                client.set_tag(run_id, "tracking_schema", str(SYNC_VERSION))
            score = root / "results" / study["name"] / identity / "evaluation.json"
            if score.is_file():
                evaluation = read_json(score)
                if sha256(score) != score.with_suffix(".sha256").read_text().strip():
                    raise ValueError("Сохранённая оценка изменена")
                if (
                    evaluation.get("record_sha256") != checksum
                    or evaluation.get("study_fingerprint") != study["fingerprint"]
                ):
                    raise ValueError("Оценка относится к другой попытке или серии")
                if any(evaluation.get(key) is not None for key in ("iou", "f_score")) and (
                    evaluation.get("evaluator_sha256") != study["source_sha256"]["src/evaluate.py"]
                ):
                    raise ValueError("Метрики рассчитаны другой версией оценщика")
                if saved.data.tags.get("evaluation_sha256") != sha256(score):
                    for key in ("iou", "f_score"):
                        if evaluation.get(key) is not None:
                            client.log_metric(
                                run_id,
                                key,
                                evaluation[key],
                                model_id=context["model_id"],
                                dataset_name=context["input"].name,
                                dataset_digest=context["input"].digest,
                            )
                    client.log_artifact(run_id, str(score))
                    client.set_tag(run_id, "evaluation_sha256", sha256(score))
                measured += int(evaluation.get("iou") is not None and evaluation.get("f_score") is not None)
            if record["status"] != "started":
                client.set_terminated(
                    run_id, status="FINISHED" if record["status"] == "success" else "FAILED"
                )
            count += 1
    log(
        "MLFLOW",
        f"{study['name']}: записей {count}, оценок {measured}. Эксперимент №{context['experiment_id']}.",
    )
    return context


def sync_all(root: Path) -> bool:
    success = True
    for path in sorted((root / "run").glob("*/study.json")):
        try:
            with FileLock(root / "artifacts" / (path.parent.name + ".lock"), timeout=0):
                sync_study(path.parent, root)
        except Exception as error:  # noqa: BLE001 — ошибка одной серии не скрывает остальные.
            success = False
            log_error(error_details(error, "синхронизация MLflow"), root / "artifacts/mlflow/sync-error.log")
    return success


def main() -> None:
    # Уже рассчитанные результаты становятся видны при обычном запуске интерфейса.
    sync_all(ROOT)
    database = uri(ROOT)
    log("MLFLOW", "Открывай http://127.0.0.1:5000 · Evaluation runs, Traces, Datasets и Agent versions.")
    os.execv(
        sys.executable,
        [
            sys.executable,
            "-m",
            "mlflow",
            "server",
            "--host",
            "127.0.0.1",
            "--port",
            "5000",
            "--backend-store-uri",
            database,
            "--no-serve-artifacts",
        ],
    )


if __name__ == "__main__":
    main()
