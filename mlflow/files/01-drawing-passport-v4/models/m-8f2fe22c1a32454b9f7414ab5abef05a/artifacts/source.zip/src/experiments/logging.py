"""Понятный журнал команды, отдельная диагностика SDK и сообщения об ожидании."""

import asyncio
import logging as std_logging
import time
from collections.abc import Awaitable, Iterator
from contextlib import contextmanager, suppress
from contextvars import ContextVar
from datetime import datetime
from pathlib import Path

from src.utils import atomic, redact
from src.utils import log as terminal_log

_journal: ContextVar[Path | None] = ContextVar("experiment_journal", default=None)
_scope: ContextVar[str] = ContextVar("experiment_scope", default="")


def append(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(redact(text) + "\n")


class SDKHandler(std_logging.Handler):
    """Служебные сообщения SDK сохраняются без лишних повторов в терминале."""

    def __init__(self, path: Path) -> None:
        super().__init__(std_logging.WARNING)
        self.path = path

    def emit(self, record: std_logging.LogRecord) -> None:
        # Не сериализуем extra, входы модели или локальные переменные исключения.
        message = std_logging.Formatter().format(record)
        try:
            append(self.path, f"{datetime.now().astimezone().isoformat()}  {_scope.get()}  {message}")
        except OSError:
            terminal_log("ВНИМАНИЕ", "Не удалось записать служебный журнал SDK.")


@contextmanager
def journal(root: Path, study: str, command: str) -> Iterator[Path]:
    """Один файл на команду серии; продолжение дописывает журнал, не стирает его."""
    path = root / "logs" / study / f"{command}.log"
    append(path, f"\n=== {datetime.now().astimezone().isoformat()} · {command} · {study} ===")
    token = _journal.set(path)
    logger = std_logging.getLogger("openai.agents")
    previous = logger.handlers[:], logger.propagate, logger.level
    handler = SDKHandler(path.parent / "sdk.log")
    logger.handlers, logger.propagate, logger.level = [handler], False, std_logging.WARNING
    try:
        log("ЖУРНАЛ", str(path.relative_to(root)))
        yield path
    except BaseException as error:
        log("ПРЕРВАНО", f"{type(error).__name__}: {redact(str(error))}")
        raise
    finally:
        logger.handlers, logger.propagate, logger.level = previous
        handler.close()
        _journal.reset(token)


@contextmanager
def scope(label: str) -> Iterator[None]:
    token = _scope.set(label)
    try:
        yield
    finally:
        _scope.reset(token)


def log(stage: str, message: str, path: Path | None = None) -> None:
    context = _scope.get()
    message = f"[{context}] {message}" if context else message
    terminal_log(stage, message, path)
    central = _journal.get()
    if central is not None and central != path:
        stamp = datetime.now().astimezone().strftime("%H:%M:%S")
        try:
            append(central, f"{stamp}  {stage:<10} {message}")
        except OSError:
            terminal_log("ВНИМАНИЕ", f"Не удалось записать журнал {central}.")


def log_error(details: dict, path: Path, logfile: Path | None = None) -> None:
    details = redact(details)
    message = details.get("summary") or f"{details['type']}: {details['message']}"
    if details.get("request_id"):
        message += f"; ID запроса: {details['request_id']}"
    log("ОШИБКА", f"{details['stage']}. {message}", logfile)
    body = (
        f"{datetime.now().astimezone().isoformat()} · {_scope.get()}\n"
        f"Этап: {details['stage']}\n{details['type']}: {details['message']}\n"
        + "\n".join(details.get("notes", []))
        + "\n\n"
        + details.get("traceback", "")
    )
    try:
        atomic(path, body.encode())
        central = _journal.get()
        if central is not None:
            append(central.parent / "errors.log", body)
        log("ПОДРОБНО", str(path), logfile)
    except OSError as error:
        log("ВНИМАНИЕ", f"Не удалось записать диагностику: {redact(str(error))}", logfile)


async def waiting[T](
    operation: Awaitable[T], label: str, timeout: float, interval: float, logfile: Path | None = None
) -> T:
    """Сообщаем реальное время ожидания; тайм-аут контролирует сам запрос или построитель."""
    started = time.monotonic()
    task = asyncio.ensure_future(operation)
    try:
        while True:
            done, _ = await asyncio.wait({task}, timeout=interval)
            if done:
                return await task
            elapsed = time.monotonic() - started
            log(
                "ОЖИДАНИЕ",
                f"{label}: прошло {elapsed:.0f} с, до лимита {max(0, timeout - elapsed):.0f} с.",
                logfile,
            )
    finally:
        if not task.done():
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task


def log_response(response: dict, limit: int, logfile: Path) -> None:
    usage = response.get("usage")
    seconds = response.get("seconds", 0)
    if usage is None:
        log("ОТВЕТ", f"Этап завершён за {seconds:.1f} с; расход токенов API не вернул.", logfile)
        return
    reasoning = (usage.get("output_tokens_details") or {}).get("reasoning_tokens")
    detail = f", рассуждения {reasoning}" if reasoning is not None else ""
    log(
        "ОТВЕТ",
        f"{seconds:.1f} с · вход {usage['input_tokens']} · "
        f"выход {usage['output_tokens']}/{limit} токенов{detail}.",
        logfile,
    )
