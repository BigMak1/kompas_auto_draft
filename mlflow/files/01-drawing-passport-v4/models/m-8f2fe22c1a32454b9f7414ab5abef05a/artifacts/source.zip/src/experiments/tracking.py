"""Локальный MLflow как представление переносимых журналов, а не единственное хранилище."""

import logging
import os
import sys
from pathlib import Path

from src.config import ROOT
from src.experiments.store import read_record, verify_study
from src.utils import read_json, sha256, write_json


def uri(root: Path) -> str:
    directory = (root / "artifacts/mlflow").resolve()
    directory.mkdir(parents=True, exist_ok=True)
    return "sqlite:///" + (directory / "tracking.db").as_posix()


def sync_study(directory: Path, root: Path) -> None:
    """Повторная синхронизация не создаёт второй MLflow run для той же попытки."""
    os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")
    from mlflow.tracking import MlflowClient

    study = verify_study(directory)
    for logger in ("mlflow", "alembic", "sqlalchemy"):
        logging.getLogger(logger).setLevel(logging.WARNING)
    client = MlflowClient(tracking_uri=uri(root))
    name = study["config"]["name"] + " · " + study["config"].get("title", "Сравнение маршрутов")
    # Уже созданные эксперименты MLflow сохраняют своё имя и идентификатор.
    legacy = (
        client.get_experiment_by_name("hw2-" + study["name"]) if "number" not in study["config"] else None
    )
    if legacy is not None:
        name = legacy.name
    experiment = client.get_experiment_by_name(name)
    experiment_id = (
        experiment.experiment_id
        if experiment
        else client.create_experiment(
            name, artifact_location=(root / "artifacts/mlflow/files").resolve().as_uri()
        )
    )
    mapping_path = root / "artifacts/mlflow" / f"{study['name']}.json"
    mapping = read_json(mapping_path) if mapping_path.exists() else {}
    for path in sorted(directory.glob("*/*/record.json")):
        record = read_record(path.parent)
        identity = path.parent.relative_to(directory).as_posix()
        score = root / "results" / study["name"] / identity / "evaluation.json"
        fingerprint = {"record": sha256(path), "evaluation": sha256(score) if score.is_file() else None}
        if identity in mapping and mapping[identity].get("fingerprint") == fingerprint:
            continue
        if identity not in mapping:
            tags = {
                "mlflow.runName": identity,
                "study": study["name"],
                "split": study["split"],
                "kind": record["kind"],
                "pair_id": record["pair_id"],
            }
            mapping[identity] = {"run_id": client.create_run(experiment_id, tags=tags).info.run_id}
            write_json(mapping_path, mapping)
        run_id = mapping[identity]["run_id"]
        parameters = {
            "variant": record.get("variant", record.get("stage", "reading")),
            "repeat": record["repeat"],
            "model": study["config"]["agent"]["model"],
            "reasoning_effort": study["config"]["agent"]["reasoning_effort"],
            "max_output_tokens": study["config"]["agent"]["max_output_tokens"],
            "timeout_seconds": study["config"]["agent"]["timeout_seconds"],
            "study_fingerprint": study["fingerprint"],
        }
        for key, value in parameters.items():
            client.log_param(run_id, key, value)
        client.set_tag(run_id, "outcome", record["status"])
        client.set_tag(run_id, "shared_reading", record.get("reading_path", ""))
        if mapping[identity].get("fingerprint", {}).get("record") != fingerprint["record"]:
            if record.get("seconds") is not None:
                client.log_metric(run_id, "seconds", record["seconds"])
            for key in ("input_tokens", "output_tokens"):
                value = (record.get("usage") or {}).get(key)
                if value is not None:
                    client.log_metric(run_id, key, value)
            client.log_artifacts(run_id, str(path.parent))
            client.log_artifact(run_id, str(directory / "study.json"))
        if score.is_file():
            evaluation = read_json(score)
            if sha256(score) != score.with_suffix(".sha256").read_text().strip():
                raise ValueError("Сохранённая оценка изменена")
            if (
                evaluation.get("record_sha256") == sha256(path)
                and evaluation.get("study_fingerprint") == study["fingerprint"]
                and evaluation.get("evaluator_sha256")
                == sha256(Path(__file__).resolve().parents[1] / "evaluate.py")
            ):
                for key in ("iou", "f_score"):
                    if evaluation.get(key) is not None:
                        client.log_metric(run_id, key, evaluation[key])
                client.log_artifact(run_id, str(score))
        if record["status"] != "started":
            client.set_terminated(run_id, status="FINISHED" if record["status"] == "success" else "FAILED")
        mapping[identity]["fingerprint"] = fingerprint
        write_json(mapping_path, mapping)


def main() -> None:
    os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")
    database = uri(ROOT)
    os.execv(
        sys.executable,
        [
            sys.executable,
            "-m",
            "mlflow",
            "server",
            "--host",
            "127.0.0.1",
            "--port",
            "5000",
            "--backend-store-uri",
            database,
            "--no-serve-artifacts",
        ],
    )


if __name__ == "__main__":
    main()
